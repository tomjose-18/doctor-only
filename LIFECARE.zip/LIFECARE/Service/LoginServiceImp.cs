﻿using LIFECARE.Models;
using LIFECARE.Repository;

namespace LIFECARE.Service
{
    public class LoginServiceImp : ILoginService
    {
        private readonly ILoginRepository _loginRepository;

        public LoginServiceImp(ILoginRepository loginRepository)
        {
            _loginRepository = loginRepository; 
        }
        public async Task<Role> GetRoleByUsernamePasswordAsync(string username, string password)
        {
            var role = await _loginRepository.GetRoleByUsernamePasswordAsync(username, password);
            return role;    
        }
    }
}
