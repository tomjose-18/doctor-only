﻿using LIFECARE.Models;

namespace LIFECARE.Repository
{
    public interface IAppointmentRepository
    {
        Task<AppointmentDetailsViewModel> GetAppointmentDetailsAsync(int appointmentId);
    }
}
