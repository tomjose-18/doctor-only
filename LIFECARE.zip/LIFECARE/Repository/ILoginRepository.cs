﻿using LIFECARE.Models;

namespace LIFECARE.Repository
{
    public interface ILoginRepository
    {
        Task<Role> GetRoleByUsernamePasswordAsync(string username, string password);
    }
}
