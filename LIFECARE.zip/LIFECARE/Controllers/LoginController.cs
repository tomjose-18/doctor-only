﻿using LIFECARE.Models;
using LIFECARE.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

public class LoginController : Controller
{
    private readonly ILoginService _loginService;
    private readonly IDoctorService _doctorService;

    public LoginController(ILoginService loginService, IDoctorService doctorService)
    {
        _loginService = loginService;
        _doctorService = doctorService;
    }

    // GET: Login/Index
    public IActionResult Index()
    {
        return View(new Login());
    }

    // POST: Login/Index
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(Login login)
    {
        try
        {
            // Call the service to get the role
            var role = await _loginService.GetRoleByUsernamePasswordAsync(login.Username, login.Password);

            if (role != null)
            {
                if (role.RoleName == "Doctor")
                {
                    // Get the doctor ID
                    var doctorId = await _doctorService.GetDoctorIdByRoleAndUsernameAsync(role.RoleName, login.Username);
                    if (doctorId.HasValue)
                    {
                        // Store the DoctorId in session
                        HttpContext.Session.SetInt32("DoctorId", doctorId.Value);
                        // Get the appointments for the doctor
                        var appointments = await _doctorService.GetAppointmentsByDoctorIdAsync(doctorId.Value);

                        // Log the number of appointments retrieved
                        Console.WriteLine($"Number of appointments retrieved: {appointments.Count()}");

                        // Check if appointments are retrieved
                        if (appointments != null && appointments.Any())
                        {
                            // Serialize appointments and store in session
                            HttpContext.Session.SetString("Appointments", JsonConvert.SerializeObject(appointments));
                            return RedirectToAction("Index", "DoctorDashboard");
                        }
                        else
                        {
                            ViewData["ErrorMessage"] = "No appointments found for the given doctor.";
                        }
                    }
                    else
                    {
                        ViewData["ErrorMessage"] = "Doctor ID not found.";
                    }
                }
                else
                {
                    // Handle other roles if necessary
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                // Role is null, set error message
                ViewData["ErrorMessage"] = "Invalid username or password.";
            }
        }
        catch (Exception ex)
        {
            // Handle unexpected errors
            ViewData["ErrorMessage"] = "An unexpected error occurred. Please try again later.";
            // Log the exception details
            Console.WriteLine($"Exception: {ex.Message}");
        }

        // Return the view with the current model and any error messages
        return View(login);
    }
}
