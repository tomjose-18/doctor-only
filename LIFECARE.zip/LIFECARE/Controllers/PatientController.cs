﻿using Microsoft.AspNetCore.Mvc;
using LIFECARE.Models;
using LIFECARE.Repository;
using System.Threading.Tasks;

namespace LIFECARE.Controllers
{
    public class PatientController : Controller
    {
        private readonly IAppointmentRepository _appointmentRepository;

        public PatientController(IAppointmentRepository appointmentRepository)
        {
            _appointmentRepository = appointmentRepository;
        }

        // GET: /Patient/ViewPatientHistory/16
        public async Task<IActionResult> ViewPatientHistory(int id)
        {
            var appointmentDetails = await _appointmentRepository.GetAppointmentDetailsAsync(id);
            return View(appointmentDetails); // Ensure that this matches the view name
        }
    }
}
