﻿namespace LIFECARE.Models
{
	public class Staff
	{
		public int StaffId { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public string Gender { get; set; }
		public DateTime DateOfBirth { get; set; }
		public string BloodGroup { get; set; }
		public DateTime JoiningDate { get; set; }
		public decimal Salary { get; set; }
		public int Experience { get; set; }
		public string PhoneNumber { get; set; }
		public string Email { get; set; }
		public string Qualification { get; set; }
		public string Address { get; set; }
		public bool IsActive { get; set; }
		public int? DepartmentId { get; set; }
		public int SpecializationId { get; set; }
		public int RoleId { get; set; }
	}
}
