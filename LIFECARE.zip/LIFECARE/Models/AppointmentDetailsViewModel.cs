﻿namespace LIFECARE.Models
{
    public class AppointmentDetailsViewModel
    {
        public string Symptoms { get; set; }
        public string Diagnosis { get; set; }
        public string TreatmentPlan { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public List<MedicinePrescriptionViewModel> Medicines { get; set; }
        public List<TestPrescriptionViewModel> Tests { get; set; }
    }
}
