﻿namespace LIFECARE.Models
{
	public class Stock
	{
	}
}
