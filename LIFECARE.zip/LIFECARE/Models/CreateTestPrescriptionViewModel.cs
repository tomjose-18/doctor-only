﻿namespace LIFECARE.Models
{
    public class CreateTestPrescriptionViewModel
    {
        public int AppointmentId { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<TestViewModel> Tests { get; set; }
    }
}
