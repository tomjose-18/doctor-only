﻿using System.ComponentModel.DataAnnotations;

namespace LIFECARE.Models
{
    public class TestViewModel
    {
        [Required]
        public string Name { get; set; }

        [Required]
        public bool IsStatus { get; set; }
    }
}
