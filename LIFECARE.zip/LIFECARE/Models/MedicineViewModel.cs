﻿using System.ComponentModel.DataAnnotations;

namespace LIFECARE.Models
{
    public class MedicineViewModel
    {
        [Required]
        public string Name { get; set; }

        public int Quantity { get; set; }

        public string Dosage { get; set; }

        public string Duration { get; set; }

        public string Frequency { get; set; }

        public bool IsMedicineStatus { get; set; }
    }
}
