﻿namespace LIFECARE.Models
{
	public class MedicineInfo
	{
		public int MedicineId { get; set; }
		public string MedicineName { get; set; }
		public string GenericName { get; set; }
		public DateTime ManufacturingDate { get; set; }
		public DateTime ExpiryDate { get; set; }
		public string Category { get; set; }
		public decimal PricePerUnit { get; set; }
		public DateTime CreatedDate { get; set; }
		public int CreatedBy { get; set; }
	}
}