﻿namespace LIFECARE.Models
{
    public class TestPrescriptionViewModel
    {
        public string TestResult { get; set; }
        public DateTime CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public string TestName { get; set; }
    }
}
